/**
 * Compute the similarity between two items based on the Cosine between item ratings
 */ 

package alg.np.similarity.metric;

import java.util.Set;

import profile.Profile;
import util.reader.DatasetReader;

public class RatingMetric implements SimilarityMetric
{
	private DatasetReader reader; // dataset reader

	/**
	 * constructor - creates a new RatingMetric object
	 * @param reader - dataset reader
	 */
	public RatingMetric(final DatasetReader reader)
	{
		this.reader = reader;
	}

	/**
	 * computes the similarity between items
	 * @param X - the id of the first item 
	 * @param Y - the id of the second item
	 */
	public double getItemSimilarity(final Integer X, final Integer Y)
	{	
		//Initializing variables for Cosine similarity calculation
		double dotproduct = 0.0;
		
		
		//Get rating profiles for X and Y
		Profile ratingX = reader.getItemProfiles().get(X);
		Profile ratingY = reader.getItemProfiles().get(Y);

		//Compute Common User Ids for Computation of Cosine Similarity
		Set<Integer> comUserIds = ratingX.getCommonIds(ratingY);
		
		//Loop through Common UserIds to compute the dotproduct. Missing UserId ratings are not considered
		for (int s: comUserIds) {
			dotproduct += ratingX.getValue(s)*ratingY.getValue(s);
		
		}
		
		// calculate similarity using Cosine
		return (ratingX.getNorm() * ratingY.getNorm()) > 0 ? dotproduct/ (ratingX.getNorm() * ratingY.getNorm()): 0;
	}
}
