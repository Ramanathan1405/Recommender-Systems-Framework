/**
 * Compute the similarity between two items based on increase in confidence
 */ 

package alg.np.similarity.metric;

import profile.Profile;
import util.reader.DatasetReader;

public class IncConfidenceMetric implements SimilarityMetric
{
	private static double RATING_THRESHOLD = 4.0; // the threshold rating for liked items 
	private DatasetReader reader; // dataset reader
	
	/**
	 * constructor - creates a new IncConfidenceMetric object
	 * @param reader - dataset reader
	 */
	public IncConfidenceMetric(final DatasetReader reader)
	{
		this.reader = reader;
	}
	
	/**
	 * computes the similarity between items
	 * @param X - the id of the first item 
	 * @param Y - the id of the second item
	 */
	public double getItemSimilarity(final Integer X, final Integer Y)
	{	
		//Initializing variables for Cosine similarity calculation
		double countX = 0.0;
		double countXY = 0.0;
		double countNXY = 0.0;
		
		//Get rating profiles for X and Y
		Profile ratingX = reader.getItemProfiles().get(X);
		Profile ratingY = reader.getItemProfiles().get(Y);
		
		//#	users which	have assigned a	rating ≥ t to X
		for(int i : ratingX.getIds()) 
		{
			if(ratingX.getValue(i)>= RATING_THRESHOLD)
				countX += 1;
		}
		
		//#	users which	have assigned a	rating ≥ t to both X and Y
		//#	users which	have assigned a rating < t to X	and	a rating ≥ t to	Y
		for (int i : ratingX.getCommonIds(ratingY)) 
		{
			if(ratingX.getValue(i)>= RATING_THRESHOLD && ratingY.getValue(i)>= RATING_THRESHOLD)
				{countXY += 1;}
			
			if(ratingX.getValue(i)< RATING_THRESHOLD && ratingY.getValue(i)>= RATING_THRESHOLD)
				{countNXY += 1;}
		}
		
		//Compute supp(X), supp(!X), supp(X and Y) and supp(!X and Y)
		double SuppX = ratingX.getSize()>0 ? (double)countX/ratingX.getSize() : 0;
		double SuppNX = ratingX.getSize()>0 ? (double)(ratingX.getSize()-countX)/ratingX.getSize():0;
		double SuppXY = ratingX.getCommonIds(ratingY).size()>0 ? (double)countXY/ratingX.getCommonIds(ratingY).size():0;
		double SuppNXY = ratingX.getCommonIds(ratingY).size()>0 ? (double)countNXY/ratingX.getCommonIds(ratingY).size():0;
		
		//Compute conf(X=>Y) and conf(!X => Y)
		double confXY = SuppX==0? 0: SuppXY/SuppX;
		double confNXY = SuppNX==0? 0: SuppNXY/SuppNX;
		
		// calculate similarity using conf(X => Y) / conf(!X => Y)
		return confNXY==0? 0 : confXY/confNXY;
	}
}
