/**
 * Compute the Mean Squared Difference similarity between profiles
 * 
 */

package similarity.metric;

import java.util.Set;

import profile.Profile;

public class CosineMetric implements SimilarityMetric
{
	/**
	 * constructor - creates a new Cosine Metric object
	 */
	public CosineMetric()
	{
	}
		
	/**
	 * computes the similarity between profiles
	 * @param profile 1 	
	 * @param profile 2
	 */
	public double getSimilarity(final Profile p1, final Profile p2)
	{
        double DotProduct = 0;
        double deno = 0;
        
        Set<Integer> common = p1.getCommonIds(p2);
		for(Integer id: common)
		{
			double r1 = p1.getValue(id).doubleValue();
			double r2 = p2.getValue(id).doubleValue();
			
			DotProduct += r1*r2;
			
		}
		//Compute Denominator(Normalization)
		
		deno = p1.getNorm()*p2.getNorm();
		
		//Return similarity
		
		return deno>0? DotProduct/deno : 0;
	}
}
