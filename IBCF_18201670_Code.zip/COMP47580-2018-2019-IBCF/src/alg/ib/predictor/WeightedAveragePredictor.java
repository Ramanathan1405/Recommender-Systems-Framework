package alg.ib.predictor;

import java.util.Map;

import alg.ib.neighbourhood.Neighbourhood;
import profile.Profile;
import similarity.SimilarityMap;

public class WeightedAveragePredictor implements Predictor {
	
	/**
	 * @returns the target user's predicted rating for the target item or null if a prediction cannot be computed
	 * @param userId - the numeric ID of the target user
	 * @param itemId - the numerid ID of the target item
	 * @param userProfileMap - a map containing user profiles
	 * @param itemProfileMap - a map containing item profiles
	 * @param neighbourhood - a Neighbourhood object
	 * @param simMap - a SimilarityMap object containing item-item similarities
	 */
	
	public Double getPrediction(Integer userId, Integer itemId, Map<Integer, Profile> userProfileMap,
			Map<Integer, Profile> itemProfileMap, Neighbourhood neighbourhood, SimilarityMap simMap) 
	{
		
		double above = 0;
		double below = 0;
		
		for(Integer id: userProfileMap.get(userId).getIds()) // iterate over the target user's items
		{
			if(neighbourhood.isNeighbour(itemId, id)) // the current item is in the neighbourhood
			{
				Double rating = userProfileMap.get(userId).getValue(id);
				above += rating.doubleValue()*simMap.getSimilarity(itemId, id);
				below += simMap.getSimilarity(itemId, id);
			}
		}
		
		return below>0? new Double(above/below) : null;
	}

}
