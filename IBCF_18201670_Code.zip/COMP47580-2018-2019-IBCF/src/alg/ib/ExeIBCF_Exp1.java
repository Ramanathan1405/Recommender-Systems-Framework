package alg.ib;

import java.io.File;

import alg.ib.neighbourhood.NearestNeighbourhood;
import alg.ib.neighbourhood.Neighbourhood;
import alg.ib.neighbourhood.ThresholdNeighbourhood;
import alg.ib.predictor.DeviationFromItemMeanPredictor;
import alg.ib.predictor.NonPersonalisedPredictor;
import alg.ib.predictor.Predictor;
import alg.ib.predictor.SimpleAveragePredictor;
import alg.ib.predictor.WeightedAveragePredictor;
import similarity.metric.CosineMetric;
import similarity.metric.MeanSquaredDifferenceMetric;
import similarity.metric.PearsonMetric;
import similarity.metric.SimilarityMetric;
import util.evaluator.Evaluator;
import util.reader.DatasetReader;
import alg.ib.printResult;

public class ExeIBCF_Exp1 {
	public static void main(String[] args)
	{
		// set the paths and filenames of the item file, genome scores file, train file and test file ...
					String folder = "ml-20m-2018-2019";
					String itemFile = folder + File.separator + "movies-sample.txt";
					String itemGenomeScoresFile = folder + File.separator + "genome-scores-sample.txt";
					String trainFile = folder + File.separator + "train.txt";
					String testFile = folder + File.separator + "test.txt";	
					
					// set the path and filename of the output file ...
					//String outputFile = "results" + File.separator + "predictions.txt";
		
		DatasetReader reader = new DatasetReader(itemFile, itemGenomeScoresFile, trainFile, testFile);

/////////////Experiment 1 - NeighbourhoodSize on Prediction/////////////////
////////////////NonPersonalized Predictor/////////////////////////////////////
		double[] RSME = new double[25];
		double[] coverage = new double[25];
		for (int k = 10, i=0; k<=250; k+=10, i++)
		{
		
			// configure the item-based CF algorithm - set the predictor, neighbourhood and similarity metric ...
			Predictor predictor = new NonPersonalisedPredictor();
			Neighbourhood neighbourhood = new NearestNeighbourhood(k);
			SimilarityMetric metric = new CosineMetric();
					
			////////////////////////////////////////////////
			// Evaluates the CF algorithm (do not change!!):
			// - the RMSE (if actual ratings are available) and coverage are output to screen
			
			ItemBasedCF ibcf = new ItemBasedCF(predictor, neighbourhood, metric, reader);
			Evaluator eval = new Evaluator(ibcf, reader.getTestData());
			
					
			// Store RSME and Coverage
			RSME[i] = eval.getRMSE();
			coverage[i] = eval.getCoverage();
		}
		System.out.println("NonPersonalisedPredictor | Neighbourhood 10 - 250 | RSME and Coverage");
		printResult.print(RSME);
		printResult.print(coverage);
///////////////////////////////////Simple Average Predictor//////////////////////////////////////////////
		double[] RSME1 = new double[25];
		double[] coverage1 = new double[25];
		for (int k = 10, i=0; k<=250; k+=10, i++)
		{
		
			// configure the item-based CF algorithm - set the predictor, neighbourhood and similarity metric ...
			Predictor predictor = new SimpleAveragePredictor();
			Neighbourhood neighbourhood = new NearestNeighbourhood(k);
			SimilarityMetric metric = new CosineMetric();
					
			////////////////////////////////////////////////
			// Evaluates the CF algorithm (do not change!!):
			// - the RMSE (if actual ratings are available) and coverage are output to screen
						
			ItemBasedCF ibcf = new ItemBasedCF(predictor, neighbourhood, metric, reader);
			Evaluator eval = new Evaluator(ibcf, reader.getTestData());
			
					
			// Store RSME and Coverage
			RSME1[i] = eval.getRMSE();
			coverage1[i] = eval.getCoverage();
		}
		System.out.println("SimpleAveragePredictor | Neighbourhood 10 - 250 | RSME and Coverage");
		printResult.print(RSME1);
		printResult.print(coverage1);
//////////////////////////////////////////WeightedAveragePredictor//////////////////////////
		double[] RSME11 = new double[25];
		double[] coverage11 = new double[25];
		for (int k = 10, i=0; k<=250; k+=10, i++)
		{
		
			// configure the item-based CF algorithm - set the predictor, neighbourhood and similarity metric ...
			Predictor predictor = new WeightedAveragePredictor();
			Neighbourhood neighbourhood = new NearestNeighbourhood(k);
			SimilarityMetric metric = new CosineMetric();
					
			////////////////////////////////////////////////
			// Evaluates the CF algorithm (do not change!!):
			// - the RMSE (if actual ratings are available) and coverage are output to screen
						
			ItemBasedCF ibcf = new ItemBasedCF(predictor, neighbourhood, metric, reader);
			Evaluator eval = new Evaluator(ibcf, reader.getTestData());
			
					
			// Store RSME and Coverage
			RSME11[i] = eval.getRMSE();
			coverage11[i] = eval.getCoverage();
		}
		System.out.println("WeightedAveragePredictor | Neighbourhood 10 - 250 | RSME and Coverage");
		printResult.print(RSME11);
		printResult.print(coverage11);
///////////////////////////////////DeviationFromItemMeanPredictor////////////////////////
		double[] RSME3 = new double[25];
		double[] coverage3 = new double[25];
		for (int k = 10, i=0; k<=250; k+=10, i++)
		{
		
			// configure the item-based CF algorithm - set the predictor, neighbourhood and similarity metric ...
			Predictor predictor = new DeviationFromItemMeanPredictor();
			Neighbourhood neighbourhood = new NearestNeighbourhood(k);
			SimilarityMetric metric = new CosineMetric();
					
			////////////////////////////////////////////////
			// Evaluates the CF algorithm (do not change!!):
			// - the RMSE (if actual ratings are available) and coverage are output to screen
						
			ItemBasedCF ibcf = new ItemBasedCF(predictor, neighbourhood, metric, reader);
			Evaluator eval = new Evaluator(ibcf, reader.getTestData());
			
					
			// Store RSME and Coverage
			RSME3[i] = eval.getRMSE();
			coverage3[i] = eval.getCoverage();
		}
		System.out.println("DeviationFromItemMeanPredictor | Neighbourhood 10 - 250 | RSME and Coverage");
		printResult.print(RSME3);
		printResult.print(coverage3);
		
	}
}




