package alg.ib;

import java.io.File;

import alg.ib.neighbourhood.NearestNeighbourhood;
import alg.ib.neighbourhood.Neighbourhood;
import alg.ib.neighbourhood.ThresholdNeighbourhood;
import alg.ib.predictor.DeviationFromItemMeanPredictor;
import alg.ib.predictor.Predictor;
import alg.ib.predictor.SimpleAveragePredictor;
import alg.ib.predictor.WeightedAveragePredictor;
import similarity.metric.CosineMetric;
import similarity.metric.MeanSquaredDifferenceMetric;
import similarity.metric.PearsonMetric;
import similarity.metric.PearsonSigWeightingMetric;
import similarity.metric.SimilarityMetric;
import util.evaluator.Evaluator;
import util.reader.DatasetReader;

public class ExeIBCF_Exp3 {
	public static void main(String[] args)
	{
		// configure the item-based CF algorithm - set the predictor, neighbourhood and similarity metric ...
		Predictor predictor = new DeviationFromItemMeanPredictor();
		Neighbourhood neighbourhood = new NearestNeighbourhood(200);
		SimilarityMetric metric = new CosineMetric();
		
		// set the paths and filenames of the item file, genome scores file, train file and test file ...
		String folder = "ml-20m-2018-2019";
		String itemFile = folder + File.separator + "movies-sample.txt";
		String itemGenomeScoresFile = folder + File.separator + "genome-scores-sample.txt";
		String trainFile = folder + File.separator + "train.txt";
		String testFile = folder + File.separator + "test.txt";	
		
	
		////////////////////////////////////////////////
		// Evaluates the CF algorithm (do not change!!):
		// - the RMSE (if actual ratings are available) and coverage are output to screen
		// - output file is created
		DatasetReader reader = new DatasetReader(itemFile, itemGenomeScoresFile, trainFile, testFile);
		ItemBasedCF ibcf = new ItemBasedCF(predictor, neighbourhood, metric, reader);
		Evaluator eval = new Evaluator(ibcf, reader.getTestData());
			
		// Display RMSE and coverage
		System.out.println("Cosine Similarity Metrics");
		Double RMSE = eval.getRMSE();
		if(RMSE != null) System.out.printf("RMSE: %.6f\n", RMSE);
		
		double coverage = eval.getCoverage();
		System.out.printf("coverage: %.2f%%\n", coverage);	
		
		//////////////////////PearsonMetric/////////////////////
		Predictor predictor1 = new DeviationFromItemMeanPredictor();
		Neighbourhood neighbourhood1 = new NearestNeighbourhood(200);
		SimilarityMetric metric1 = new PearsonMetric();
		ItemBasedCF ibcf1 = new ItemBasedCF(predictor1, neighbourhood1, metric1, reader);
		Evaluator eval1 = new Evaluator(ibcf1, reader.getTestData());
			
		// Display RMSE and coverage
		System.out.println("Pearson Similarity Metrics");
		Double RMSE1 = eval1.getRMSE();
		if(RMSE1 != null) System.out.printf("RMSE: %.6f\n", RMSE1);
		
		double coverage1 = eval1.getCoverage();
		System.out.printf("coverage: %.2f%%\n", coverage1);	
		
		/////////////////////PearsonSigWeightingMetric//////////////////
		Predictor predictor2 = new DeviationFromItemMeanPredictor();
		Neighbourhood neighbourhood2 = new NearestNeighbourhood(200);
		SimilarityMetric metric2 = new PearsonSigWeightingMetric(50);
		ItemBasedCF ibcf2 = new ItemBasedCF(predictor2, neighbourhood2, metric2, reader);
		Evaluator eval2 = new Evaluator(ibcf2, reader.getTestData());
			
		// Display RMSE and coverage
		System.out.println("Pearson Sig Weighting Similarity Metrics");
		Double RMSE2 = eval2.getRMSE();
		if(RMSE2 != null) System.out.printf("RMSE: %.6f\n", RMSE2);
		
		double coverage2 = eval2.getCoverage();
		System.out.printf("coverage: %.2f%%\n", coverage2);	
		
		/////////////////////MeanSquaredDifferenceMetric//////////////////
		Predictor predictor3 = new DeviationFromItemMeanPredictor();
		Neighbourhood neighbourhood3 = new NearestNeighbourhood(200);
		SimilarityMetric metric3 = new MeanSquaredDifferenceMetric();
		ItemBasedCF ibcf3 = new ItemBasedCF(predictor3, neighbourhood3, metric3, reader);
		Evaluator eval3 = new Evaluator(ibcf3, reader.getTestData());
		
		// Display RMSE and coverage
		System.out.println("Mean Squared Difference Similarity Metric");
		Double RMSE3 = eval3.getRMSE();
		if(RMSE3 != null) System.out.printf("RMSE: %.6f\n", RMSE3);
		
		double coverage3 = eval3.getCoverage();
		System.out.printf("coverage: %.2f%%\n", coverage3);	
	}
}
