package alg.ib;

public class printResult 
{
	
	public static void print(double[] arr)
	{
		for(int i=0;i<arr.length;i++)
			System.out.printf("%.6f,",arr[i]);
		System.out.println();
	}
	

}
