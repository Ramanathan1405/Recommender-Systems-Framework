package alg.ib.neighbourhood;

import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;

import profile.Profile;
import similarity.SimilarityMap;
import util.ScoredThingDsc;

public class ThresholdNeighbourhood extends Neighbourhood 
{
	private final double t; // Threshold for neighborhood
	
	/**
	 * constructor - creates a new ThresholdNeighbourhood object
	 * @param t - Threshold for neighbourhood
	 */
	public ThresholdNeighbourhood(final double t)
	{
		super();
		this.t = t;
	}
	
	/**
	 * stores the neighbourhoods for all items in member Neighbour.neighbourhoodMap
	 * @param simMap - a map containing item-item similarities
	 */
	
	public void computeNeighbourhoods(SimilarityMap simMap)
	{
		for(Integer itemId: simMap.getIds()) // iterate over each item
		{
			SortedSet<ScoredThingDsc> ss = new TreeSet<ScoredThingDsc>(); // for the current item, store all similarities in order of descending similarity in a sorted set

			Profile profile = simMap.getSimilarities(itemId); // get the item similarity profile
			if(profile != null)
			{
				for(Integer id: profile.getIds()) // iterate over each item in the profile
				{
					double sim = profile.getValue(id);
					if(sim > t)							//Check if Similarity is greater than Threshold
						ss.add(new ScoredThingDsc(sim, id));
				}
			}

			// Store the items(id(s)) into neighbourhoodMap for itemID
			for(Iterator<ScoredThingDsc> iter = ss.iterator(); iter.hasNext(); )
			{
				ScoredThingDsc st = iter.next();
				Integer id = (Integer)st.thing;
				this.add(itemId, id);
				
			}
		}

	}

}
